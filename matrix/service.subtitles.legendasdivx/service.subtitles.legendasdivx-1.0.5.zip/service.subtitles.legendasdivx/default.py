# -*- coding: utf-8 -*-
# Service LegendasDivx.com

#simple call, it's just a subtitle addon
from service import Main

#run the program
Main().get_params