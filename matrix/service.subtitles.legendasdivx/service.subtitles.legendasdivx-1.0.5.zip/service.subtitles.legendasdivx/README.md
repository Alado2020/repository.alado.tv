service.subtitles.legendasdivx
=========================

LegendasDivx.com subtitle service plugin for XBMC 19 Matrix or newer.<br>
Ported from the Gotham (python2) to Matrix (python3).


HiGhLaNdeR
<br><a href="mailto:highlander@teknorage.com">mail me</a> for bugs